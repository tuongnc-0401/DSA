package com.company;

public class DailyTasks {
    public static void main(String[] args){
        DailyTasks tasks = new DailyTasks();
        System.out.println(tasks.addTask(new Task("Styding DSA", 10, 2)));
        System.out.println(tasks.addTask(new Task("programming", 8, 2)));
        System.out.println(tasks.addTask(new Task("hacking", 20, 2)));
        System.out.println(tasks.addTask(new Task("hacking", 21, 2)));


        System.out.println(tasks.nextTask(5));
        System.out.println(tasks.nextTask(8));
        System.out.println(tasks.nextTask(9));
        System.out.println(tasks.nextTask(21));
    }

    private class Node<E>{
        public E data;
        public Node next;
        public Node prev;
    }

    private Node<Task> head;

    public boolean validateTask(Task task){
        return task.getStartTime() + task.getDuration() <= 24;
    }

    public boolean addTask(Task task){
        //check validity
        if(!validateTask(task)) return false;

        //try to add task to the list
        //task endtime
        int taskEndtime = task.getStartTime() + task.getDuration();
        int lastEndTime = 0;
        Node<Task> current = head;

        //if list is empty
        if(head == null){
            //create newNode
            Node<Task> newNode = new Node<>();
            newNode.data = task;
            newNode.next = null;
            newNode.prev = null;

            head = newNode;

            return true;
        }

        while(current != null){
            Task currentTask = current.data;
            if(taskEndtime <= currentTask.getStartTime() && task.getStartTime() >= lastEndTime){
                //create newNode
                Node<Task> newNode = new Node<>();
                newNode.data = task;
                newNode.next = current;
                newNode.prev = current.prev;

                //update current node
                if(current == head){
                    head = newNode;
                }
                else current.prev.next = newNode;

                current.prev = newNode;

                return true;

                //check if task intersect
            } else if((taskEndtime > currentTask.getStartTime() && taskEndtime <= (currentTask.getStartTime() + currentTask.getDuration()))
            || (task.getStartTime() >= currentTask.getStartTime() && task.getStartTime() < (currentTask.getStartTime() + currentTask.getDuration()))) {
                return false;
            } else {
                lastEndTime = current.data.getStartTime() + current.data.getDuration();

                //check if there is a next node
                if(current.next == null) break;

                current = current.next;
            }
        }

        if(task.getStartTime() > lastEndTime){
            //create newNode
            Node<Task> newNode = new Node<>();
            newNode.data = task;
            newNode.next = null;
            newNode.prev = current;

            //update current node
            current.next = newNode;

            return true;
        }

        //cannot add the task to the list
        return false;
    }

    public String nextTask(int time){
        Node<Task> current = head;
        while(current != null){
            if(current.data.getStartTime() >= time) return current.data.getDescription();
            current = current.next;
        }

        return "";
    }
}

class Task{
    private String description;
    private int startTime;
    private int duration;

    public Task(String description, int startTime, int duration){
        this.description = description;
        this.startTime = startTime;
        this.duration = duration;
    }

    public String getDescription(){
        return description;
    }

    public int getStartTime(){
        return startTime;
    }

    public int getDuration(){
        return duration;
    }
}
